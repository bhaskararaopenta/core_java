package com.training.service;

import java.util.List;

import com.training.dto.ProjectDTO;
import com.training.exception.BugTracking;

public interface ProjectService {

	public ProjectDTO addProject(ProjectDTO projectDTO) throws BugTracking;

	public ProjectDTO deleteProject(Long id) throws BugTracking;

	public ProjectDTO getProject(Long id) throws BugTracking;

	public List<ProjectDTO> getAllProjects() throws BugTracking;

	public ProjectDTO updateProject(Long id, ProjectDTO projectDTO) throws BugTracking;
}
