package com.training.service;

import java.util.List;

import com.training.dto.EmployeeDTO;
import com.training.entity.Employee;
import com.training.exception.BugTracking;

public interface EmployeeService {

	EmployeeDTO createEmployee(EmployeeDTO employeeDTO) throws BugTracking;

	EmployeeDTO updateEmployee(long id, EmployeeDTO employeeDTO) throws BugTracking;

	EmployeeDTO deleteEmployee(long id) throws BugTracking;

	EmployeeDTO getEmployee(long id) throws BugTracking;

	List<EmployeeDTO> getAllEmployees() throws BugTracking;

}
