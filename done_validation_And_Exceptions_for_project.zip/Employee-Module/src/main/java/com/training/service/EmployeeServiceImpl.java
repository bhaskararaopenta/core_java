package com.training.service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.dto.EmployeeDTO;
import com.training.entity.Employee;
import com.training.exception.BugTracking;
import com.training.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public EmployeeDTO createEmployee(EmployeeDTO employeeDTO) throws BugTracking {
		// Convert DTO to entity
		Employee emp = new Employee();
		emp.setEmpId(employeeDTO.getEmpId());
		emp.setEmpName(employeeDTO.getEmpName());
		emp.setEmail(employeeDTO.getEmail());
		emp.setEmpContact(employeeDTO.getEmpContact());
		emp.setProjId(employeeDTO.getProjId());

		Employee savedEmployee = employeeRepository.save(emp);

		// Convert the saved entity back to DTO
		EmployeeDTO savedEmployeeDTO = new EmployeeDTO();
		savedEmployeeDTO.setEmpId(savedEmployee.getEmpId());
		savedEmployeeDTO.setEmpName(savedEmployee.getEmpName());
		savedEmployeeDTO.setEmail(savedEmployee.getEmail());
		savedEmployeeDTO.setEmpContact(savedEmployee.getEmpContact());
		savedEmployeeDTO.setProjId(savedEmployee.getProjId());

		return savedEmployeeDTO;
	}

	@Override
	public EmployeeDTO getEmployee(long id) throws BugTracking {
		Optional<Employee> employeeOpt = employeeRepository.findById(id);

		Employee employee = employeeOpt.orElseThrow(() -> new BugTracking("Service.EMPLOYEE_NOT_FOUND"));

		EmployeeDTO employeeDTO = new EmployeeDTO();
		employeeDTO.setEmpId(employee.getEmpId());
		employeeDTO.setEmpName(employee.getEmpName());
		employeeDTO.setEmail(employee.getEmail());
		employeeDTO.setEmpContact(employee.getEmpContact());
		employeeDTO.setProjId(employee.getProjId());
		return employeeDTO;

	}

	@Override
	public EmployeeDTO deleteEmployee(long id) throws BugTracking {
		Optional<Employee> employeeOpt = employeeRepository.findById(id);
		Employee employee = employeeOpt.orElseThrow(() -> new BugTracking("Service.EMPLOYEE_NOT_FOUND"));
		employeeRepository.delete(employee);

		EmployeeDTO employeeDTO = new EmployeeDTO();
		employeeDTO.setEmpId(employee.getEmpId());
		employeeDTO.setEmpName(employee.getEmpName());
		employeeDTO.setEmail(employee.getEmail());
		employeeDTO.setEmpContact(employee.getEmpContact());
		employeeDTO.setProjId(employee.getProjId());
		return employeeDTO;

	}

	@Override
	public List<EmployeeDTO> getAllEmployees() throws BugTracking {
		List<EmployeeDTO> employeeDTOs = new ArrayList<>();
		List<Employee> employees = employeeRepository.findAll();
		for (Employee employee : employees) {
			EmployeeDTO dto = new EmployeeDTO();
			dto.setEmpId(employee.getEmpId());
			dto.setEmpName(employee.getEmpName());
			dto.setEmail(employee.getEmail());
			dto.setEmpContact(employee.getEmpContact());
			dto.setProjId(employee.getProjId());

			employeeDTOs.add(dto);
		}
		if (employeeDTOs.isEmpty()) {
			throw new BugTracking("Service.EMPLOYEES_NOT_FOUND");
		}
		return employeeDTOs;
	}

	@Override
	public EmployeeDTO updateEmployee(long id, EmployeeDTO employeeDTO) throws BugTracking {
		Optional<Employee> optionalEmployee = employeeRepository.findById(id);
		Employee existingEmployee = optionalEmployee.orElseThrow(() -> new BugTracking("Service.EMPLOYEE_NOT_FOUND"));

		// Update only the provided fields
		if (employeeDTO.getEmpName() != null) {
			existingEmployee.setEmpName(employeeDTO.getEmpName());
		}
		if (employeeDTO.getEmail() != null) {
			existingEmployee.setEmail(employeeDTO.getEmail());
		}
		if (employeeDTO.getEmpContact() != null) {
			existingEmployee.setEmpContact(employeeDTO.getEmpContact());
		}
		/*
		 * if (employeeDTO.getProjId() != null) {
		 * existingEmployee.setProjId(employeeDTO.getProjId()); }
		 */

		Employee updatedEmployee = employeeRepository.save(existingEmployee);

		EmployeeDTO updatedEmployeeDTO = new EmployeeDTO();
		updatedEmployeeDTO.setEmpId(updatedEmployee.getEmpId());
		updatedEmployeeDTO.setEmpName(updatedEmployee.getEmpName());
		updatedEmployeeDTO.setEmail(updatedEmployee.getEmail());
		updatedEmployeeDTO.setEmpContact(updatedEmployee.getEmpContact());
		updatedEmployeeDTO.setProjId(updatedEmployee.getProjId());

		return updatedEmployeeDTO;
	}
}
