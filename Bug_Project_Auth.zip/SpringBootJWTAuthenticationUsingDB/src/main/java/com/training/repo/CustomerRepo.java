package com.training.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.training.entity.UserLogin;


@Repository
public interface CustomerRepo extends CrudRepository<UserLogin,Long> {

	public UserLogin findByRole(String role);

}
