package com.training.service;

import java.util.List;

import com.training.dto.EmployeeDTO;
import com.training.entity.Employee;

public interface EmployeeService {

	EmployeeDTO createEmployee(EmployeeDTO employeeDTO);

	EmployeeDTO updateEmployee(long id , EmployeeDTO employeeDTO);

	EmployeeDTO deleteEmployee(long id);

	EmployeeDTO getEmployee(long id);

	List<EmployeeDTO> getAllEmployees();
}
