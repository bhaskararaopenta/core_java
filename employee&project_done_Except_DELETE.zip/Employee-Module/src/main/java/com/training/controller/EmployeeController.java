package com.training.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.consumes.EmployeeConsumesProject;
import com.training.dto.EmployeeDTO;
import com.training.dto.ProjectDTO;
import com.training.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private EmployeeConsumesProject employeeConsumesProject;

	@Autowired
	private Environment environment;

	/*
	 * @PostMapping("/create") public ResponseEntity<EmployeeDTO>
	 * addEmployee(@RequestBody EmployeeDTO employeeDTO) { try { // Fetch project
	 * details from Project module ProjectDTO projectDTO =
	 * employeeConsumesProject.getEmplyoeeConsumesProjectById(employeeDTO.getProjId(
	 * )); employeeDTO.setProjId(projectDTO.getProjId()); // Set projId from
	 * ProjectDTO
	 * 
	 * // Update project manager with the new employee EmployeeDTO
	 * newEmployeeForProject = new EmployeeDTO();
	 * newEmployeeForProject.setEmpId(employeeDTO.getEmpId());
	 * newEmployeeForProject.setEmpName(employeeDTO.getEmpName());
	 * newEmployeeForProject.setEmail(employeeDTO.getEmail());
	 * newEmployeeForProject.setEmpContact(employeeDTO.getEmpContact());
	 * 
	 * List<EmployeeDTO> projManagers = projectDTO.getProjManager();
	 * projManagers.add(newEmployeeForProject);
	 * projectDTO.setProjManager(projManagers);
	 * employeeConsumesProject.updateProject(projectDTO.getProjId(), projectDTO); }
	 * catch (Exception e) { // If project doesn't exist, set projId to null
	 * employeeDTO.setProjId(null); }
	 * 
	 * EmployeeDTO savedEmployeeDTO = employeeService.createEmployee(employeeDTO);
	 * return new ResponseEntity<>(savedEmployeeDTO, HttpStatus.CREATED); }
	 */

	@PostMapping("/create")
	public ResponseEntity<EmployeeDTO> addEmployee(@RequestBody EmployeeDTO employeeDTO) {
		try {
			// Fetch project details from Project module
			ProjectDTO projectDTO = employeeConsumesProject.getEmplyoeeConsumesProjectById(employeeDTO.getProjId());
			if (projectDTO != null) {
				employeeDTO.setProjId(projectDTO.getProjId()); // Set projId from ProjectDTO
			} else {
				// If project doesn't exist, set projId to null
				employeeDTO.setProjId(null);
			}
		} catch (Exception e) {
			// Log the exception
			System.err.println("Error fetching project: " + e.getMessage());
			// If project doesn't exist, set projId to null
			employeeDTO.setProjId(null);
		}

		// Save the employee
		EmployeeDTO savedEmployeeDTO = employeeService.createEmployee(employeeDTO);

		try {
			if (savedEmployeeDTO.getProjId() != null) {
				// Fetch the project again to update the manager list
				ProjectDTO projectDTO = employeeConsumesProject
						.getEmplyoeeConsumesProjectById(savedEmployeeDTO.getProjId());
				if (projectDTO != null) {
					// Update project manager with the new employee
					EmployeeDTO newEmployeeForProject = new EmployeeDTO();
					newEmployeeForProject.setEmpId(savedEmployeeDTO.getEmpId());
					newEmployeeForProject.setEmpName(savedEmployeeDTO.getEmpName());
					newEmployeeForProject.setEmail(savedEmployeeDTO.getEmail());
					newEmployeeForProject.setEmpContact(savedEmployeeDTO.getEmpContact());

					List<EmployeeDTO> projManagers = projectDTO.getProjManager();
					if (projManagers == null) {
						projManagers = new ArrayList<>();
					}
					projManagers.add(newEmployeeForProject);
					projectDTO.setProjManager(projManagers);
					employeeConsumesProject.updateProject(projectDTO.getProjId(), projectDTO);
				}
			}
		} catch (Exception e) {
			// Log the exception
			System.err.println("Error updating project: " + e.getMessage());
		}

		return new ResponseEntity<>(savedEmployeeDTO, HttpStatus.CREATED);
	}

	@GetMapping(value = "/get/{employeeId}")
	public ResponseEntity<EmployeeDTO> getEmployee(@PathVariable Long employeeId) {
		EmployeeDTO employeeDTO = employeeService.getEmployee(employeeId);
		return new ResponseEntity<>(employeeDTO, HttpStatus.OK);
	}

	@GetMapping(value = "/allemployees")
	public ResponseEntity<List<EmployeeDTO>> getAllEmployees() {
		List<EmployeeDTO> employeeDTOs = employeeService.getAllEmployees();
		return new ResponseEntity<>(employeeDTOs, HttpStatus.OK);
	}

	@DeleteMapping(value = "/delete/{employeeId}")
	public ResponseEntity<String> deleteEmployee(@PathVariable Long employeeId) {
		employeeService.deleteEmployee(employeeId);
		String successMessage = environment.getProperty("API.DELETE_SUCCESS") + employeeId;
		return new ResponseEntity<>(successMessage, HttpStatus.OK);
	}

	@PutMapping(value = "/update/{employeeId}")
	public ResponseEntity<EmployeeDTO> updateEmployee(@PathVariable Long employeeId,
			@RequestBody EmployeeDTO employeeDTO) {
		EmployeeDTO updatedEmployeeDTO = employeeService.updateEmployee(employeeId, employeeDTO);
		return new ResponseEntity<>(updatedEmployeeDTO, HttpStatus.OK);
	}

}
