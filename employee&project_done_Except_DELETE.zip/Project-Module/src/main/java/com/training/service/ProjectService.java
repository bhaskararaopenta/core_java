package com.training.service;

import java.util.List;

import com.training.dto.ProjectDTO;

public interface ProjectService {

	public ProjectDTO addProject(ProjectDTO projectDTO);

	public ProjectDTO deleteProject(Long id);

	public ProjectDTO getProject(Long id);

	public List<ProjectDTO> getAllProjects();

	public ProjectDTO updateProject(Long id, ProjectDTO projectDTO);
}
