package com.training.dto;

import java.util.List;

public class ProjectDTO {

	private Long projId;
	private String projName;
	private List<EmployeeForProject> projManager;		
	private String projStatus;

	public Long getProjId() {
		return projId;
	}

	public void setProjId(Long projId) {
		this.projId = projId;
	}

	public String getProjName() {
		return projName;
	}

	public void setProjName(String projName) {
		this.projName = projName;
	}

	public List<EmployeeForProject> getProjManager() {
		return projManager;
	}

	public void setProjManager(List<EmployeeForProject> projManager) {
		this.projManager = projManager;
	}

	public String getProjStatus() {
		return projStatus;
	}

	public void setProjStatus(String projStatus) {
		this.projStatus = projStatus;
	}

	@Override
	public String toString() {
		return "ProjectDTO [projId=" + projId + ", projName=" + projName + ", projManager=" + projManager
				+ ", projStatus=" + projStatus + "]";
	}

}
