package com.training.dto;

public class EmployeeProject {

	private Long empId;
	private String empName;
	private String email;
	private String empContact;

	private Long projId;
	private String projName;
	private EmployeeForProject projManager;
	private String projStatus;

	public Long getEmpId() {
		return empId;
	}

	public void setEmpId(Long empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmpContact() {
		return empContact;
	}

	public void setEmpContact(String empContact) {
		this.empContact = empContact;
	}

	public Long getProjId() {
		return projId;
	}

	public void setProjId(Long projId) {
		this.projId = projId;
	}

	public String getProjName() {
		return projName;
	}

	public void setProjName(String projName) {
		this.projName = projName;
	}

	public EmployeeForProject getProjManager() {
		return projManager;
	}

	public void setProjManager(EmployeeForProject projManager) {
		this.projManager = projManager;
	}

	public String getProjStatus() {
		return projStatus;
	}

	public void setProjStatus(String projStatus) {
		this.projStatus = projStatus;
	}

	@Override
	public String toString() {
		return "EmployeeProject [empId=" + empId + ", empName=" + empName + ", email=" + email + ", empContact="
				+ empContact + ", projId=" + projId + ", projName=" + projName + ", projManager=" + projManager
				+ ", projStatus=" + projStatus + "]";
	}

}
