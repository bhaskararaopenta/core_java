package com.training.dto;

import java.util.List;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class ProjectDTO {

	private Long projId;
	@NotNull(message = "Project name cannot be null")
    @Size(min = 1, max = 100, message = "Project name must be between 1 and 100 characters")
	private String projName;
	private List<EmployeeForProject> projManager;	
	@NotNull(message = "Project status cannot be null")
	private String projStatus;	

	public Long getProjId() {
		return projId;
	}

	public void setProjId(Long projId) {
		this.projId = projId;
	}

	public String getProjName() {
		return projName;
	}

	public void setProjName(String projName) {
		this.projName = projName;
	}

	public List<EmployeeForProject> getProjManager() {
		return projManager;
	}

	public void setProjManager(List<EmployeeForProject> projManager) {
		this.projManager = projManager;
	}

	public String getProjStatus() {
		return projStatus;
	}

	public void setProjStatus(String projStatus) {
		this.projStatus = projStatus;
	}

	@Override
	public String toString() {
		return "ProjectDTO [projId=" + projId + ", projName=" + projName + ", projManager=" + projManager
				+ ", projStatus=" + projStatus + "]";
	}

}
