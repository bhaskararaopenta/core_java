package com.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.training.dto.Department;
import com.training.dto.UserDepartment;
import com.training.entity.User;
import com.training.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private DiscoveryClient client;

	@Override
	public User saveUser(User user) {
		return userRepository.save(user);
	}

	@Override
	public UserDepartment getUser(Long userId) {

		User user = userRepository.findById(userId).get();
		String id = user.getDepartmentId();

		// String url = "http://localhost:8000/api/dept/" + id;

		// get serviceInstance list using serviceId
		List<ServiceInstance> siList = client.getInstances("Department-Service");

		// read manually one instance from index#0
		ServiceInstance si = siList.get(0);

		// read URI and add path that returns url
		String url = si.getUri() + "/api/dept/"+id;

		ResponseEntity<Department> respET = restTemplate.getForEntity(url, Department.class);
		Department d = respET.getBody();

		UserDepartment ud = new UserDepartment();
		ud.setUserId(user.getId());
		ud.setFirstName(user.getFirstName());
		ud.setLastName(user.getLastName());
		ud.setEmail(user.getEmail());
		ud.setDeptId(d.getId());
		ud.setDepartmentName(d.getDepartmentName());
		ud.setDepartmentAddress(d.getDepartmentAddress());
		ud.setDepartmentCode(d.getDepartmentCode());

		return ud;
	}

	/*
	 * private UserDto mapToUser(User user){ UserDto userDto = new UserDto();
	 * userDto.setId(user.getId()); userDto.setFirstName(user.getFirstName());
	 * userDto.setLastName(user.getLastName()); userDto.setEmail(user.getEmail());
	 * return userDto; }
	 */
}
