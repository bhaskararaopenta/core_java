package com.training.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.consumes.ProjectConsumesDataFromEmployee;

import com.training.dto.EmployeeForProject;
import com.training.dto.ProjectDTO;
import com.training.exception.BugTracking;
import com.training.service.ProjectService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;

@RestController
@RequestMapping("/project")
@Validated
public class ProjectController {

	@Autowired
	private ProjectService projectService;

	@Autowired
	private ProjectConsumesDataFromEmployee consumesDataFromEmployee;

	@Autowired
	private Environment environment;

	// one to one

	/*
	 * @PostMapping("/create") public ResponseEntity<ProjectDTO>
	 * addProject(@RequestBody ProjectDTO projectDTO) {
	 * 
	 * EmployeeForProject employeeDTO = null; EmployeeForProject insertRecord =
	 * null; if (projectDTO.getProjManager().getEmpId() != null) {
	 * 
	 * employeeDTO = consumesDataFromEmployee
	 * .getProjectConsumesEmployeeById(projectDTO.getProjManager().getEmpId()); } //
	 * If the employee doesn't exist, create the employee if (employeeDTO == null) {
	 * 
	 * employeeDTO = new EmployeeForProject();
	 * employeeDTO.setEmpId(projectDTO.getProjManager().getEmpId());
	 * employeeDTO.setEmpName(projectDTO.getProjManager().getEmpName());
	 * employeeDTO.setEmail(projectDTO.getProjManager().getEmail());
	 * employeeDTO.setEmpContact(projectDTO.getProjManager().getEmpContact());
	 * 
	 * // Save the new employee using employee-service employeeDTO = insertRecord =
	 * consumesDataFromEmployee.createEmployee(employeeDTO);
	 * projectDTO.setProjManager(insertRecord);
	 * 
	 * } else { projectDTO.setProjManager(employeeDTO); }
	 * 
	 * ProjectDTO savedProjectDTO = projectService.addProject(projectDTO); return
	 * new ResponseEntity<>(savedProjectDTO, HttpStatus.CREATED); }
	 */

	@PostMapping("/create")
	public ResponseEntity<ProjectDTO> addProject(@Valid @RequestBody ProjectDTO projectDTO) throws BugTracking {
		List<EmployeeForProject> projManagers = new ArrayList<>();

		for (EmployeeForProject emp : projectDTO.getProjManager()) {
			EmployeeForProject employeeDTO = null;
			EmployeeForProject insertRecord = null;

			if (emp.getEmpId() != null) {
				employeeDTO = consumesDataFromEmployee.getProjectConsumesEmployeeById(emp.getEmpId());
			}

			if (employeeDTO == null) {
				employeeDTO = new EmployeeForProject();
				employeeDTO.setEmpId(emp.getEmpId());
				employeeDTO.setEmpName(emp.getEmpName());
				employeeDTO.setEmail(emp.getEmail());
				employeeDTO.setEmpContact(emp.getEmpContact());

				insertRecord = consumesDataFromEmployee.createEmployee(employeeDTO);
				projManagers.add(insertRecord);
			} else {
				projManagers.add(employeeDTO);
			}
		}

		projectDTO.setProjManager(projManagers);

		// Save the project
		ProjectDTO savedProjectDTO = projectService.addProject(projectDTO);

		// Update projId in each employee
		for (EmployeeForProject emp : projManagers) {
			emp.setProjId(savedProjectDTO.getProjId());
			consumesDataFromEmployee.updateEmployee(emp.getEmpId(), emp);
		}

		return new ResponseEntity<>(savedProjectDTO, HttpStatus.CREATED);
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<ProjectDTO> getProject(@PathVariable @Min(1) Long id) throws Exception {
		ProjectDTO projectDTO = projectService.getProject(id); // Fetch the project details

		List<EmployeeForProject> projManagers = new ArrayList<>();

		for (EmployeeForProject emp : projectDTO.getProjManager()) {
			EmployeeForProject employeeDTO = consumesDataFromEmployee.getProjectConsumesEmployeeById(emp.getEmpId());
			projManagers.add(employeeDTO);
		}

		projectDTO.setProjManager(projManagers);

		return new ResponseEntity<>(projectDTO, HttpStatus.OK);
	}

	@GetMapping("/allprojects")
	public ResponseEntity<List<ProjectDTO>> getAllProjects() throws Exception {
		List<ProjectDTO> projectDTOs = projectService.getAllProjects(); // Fetch all projects

		for (ProjectDTO projectDTO : projectDTOs) {
			List<EmployeeForProject> projManagers = new ArrayList<>();

			for (EmployeeForProject emp : projectDTO.getProjManager()) {
				EmployeeForProject employeeDTO = consumesDataFromEmployee
						.getProjectConsumesEmployeeById(emp.getEmpId());
				projManagers.add(employeeDTO);
			}

			projectDTO.setProjManager(projManagers);
		}

		return new ResponseEntity<>(projectDTOs, HttpStatus.OK);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteProject(@PathVariable @Min(1) Long id) throws Exception {
		projectService.deleteProject(id);
		String successMessage = environment.getProperty("API.DELETE_SUCCESS") + id;
		return new ResponseEntity<>(successMessage, HttpStatus.OK);
	}

	// this update method will update every field even emplyoee also we can update

	/*
	 * @PutMapping("/update/{id}") public ResponseEntity<ProjectDTO>
	 * updateProject(@PathVariable Long id, @RequestBody ProjectDTO projectDTO) { //
	 * Fetch // the // existing // project ProjectDTO existingProject =
	 * projectService.getProject(id);
	 * 
	 * // Retain existing project details if not provided if
	 * (projectDTO.getProjName() == null) {
	 * projectDTO.setProjName(existingProject.getProjName()); } if
	 * (projectDTO.getProjManager() == null) {
	 * projectDTO.setProjManager(existingProject.getProjManager());k } else {
	 * List<EmployeeForProject> updatedEmployees = new ArrayList<>();
	 * 
	 * // Update the specified employees for (EmployeeForProject emp :
	 * projectDTO.getProjManager()) { EmployeeForProject employeeDTO =
	 * consumesDataFromEmployee .getProjectConsumesEmployeeById(emp.getEmpId());
	 * 
	 * if (employeeDTO != null) { // Update the employee details
	 * employeeDTO.setEmpName(emp.getEmpName());
	 * employeeDTO.setEmail(emp.getEmail());
	 * employeeDTO.setEmpContact(emp.getEmpContact());
	 * 
	 * // Save the updated employee using employee-service employeeDTO =
	 * consumesDataFromEmployee.updateEmployee(employeeDTO.getEmpId(), employeeDTO);
	 * updatedEmployees.add(employeeDTO); } }
	 * 
	 * // Add the unchanged employees to the updated list using a for loop for
	 * (EmployeeForProject existingEmp : existingProject.getProjManager()) { boolean
	 * isUpdated = false; for (EmployeeForProject updatedEmp : updatedEmployees) {
	 * if (updatedEmp.getEmpId().equals(existingEmp.getEmpId())) { isUpdated = true;
	 * break; } } if (!isUpdated) { updatedEmployees.add(existingEmp); } }
	 * 
	 * projectDTO.setProjManager(updatedEmployees); } if (projectDTO.getProjStatus()
	 * == null) { projectDTO.setProjStatus(existingProject.getProjStatus()); }
	 * 
	 * ProjectDTO updatedProjectDTO = projectService.updateProject(id, projectDTO);
	 * return new ResponseEntity<>(updatedProjectDTO, HttpStatus.OK); }
	 */

	// this update method will update only project details not the emplyoee
	/*
	 * @PutMapping("/update/{id}") public ResponseEntity<ProjectDTO>
	 * updateProject(@PathVariable Long id, @RequestBody ProjectDTO projectDTO) { //
	 * Fetch the existing project ProjectDTO existingProject =
	 * projectService.getProject(id);
	 * 
	 * // Retain existing project details if not provided if
	 * (projectDTO.getProjName() == null) {
	 * projectDTO.setProjName(existingProject.getProjName()); } if
	 * (projectDTO.getProjManager() == null) { // Fetch all employees linked to the
	 * project projectDTO.setProjManager(existingProject.getProjManager()); } if
	 * (projectDTO.getProjStatus() == null) {
	 * projectDTO.setProjStatus(existingProject.getProjStatus()); }
	 * 
	 * // Update the project with the new details ProjectDTO updatedProjectDTO =
	 * projectService.updateProject(id, projectDTO); return new
	 * ResponseEntity<>(updatedProjectDTO, HttpStatus.OK); }
	 */

	@PutMapping("/update/{id}")
	public ResponseEntity<ProjectDTO> updateProject(@PathVariable @Min(1) Long id, @RequestBody ProjectDTO projectDTO)
			throws BugTracking {
		// Fetch the existing project
		ProjectDTO existingProject = projectService.getProject(id);

		// Retain existing project details if not provided
		if (projectDTO.getProjName() == null) {
			projectDTO.setProjName(existingProject.getProjName());
		}
		if (projectDTO.getProjManager() == null) {
			projectDTO.setProjManager(existingProject.getProjManager());
		} else {
			List<EmployeeForProject> updatedEmployees = new ArrayList<>();

			// Update the specified employees
			for (EmployeeForProject emp : projectDTO.getProjManager()) {
				EmployeeForProject employeeDTO = consumesDataFromEmployee
						.getProjectConsumesEmployeeById(emp.getEmpId());

				if (employeeDTO != null) { // Update only the projId
					employeeDTO.setProjId(id);

					// Save the updated employee using employee-service
					employeeDTO = consumesDataFromEmployee.updateEmployee(employeeDTO.getEmpId(), employeeDTO);
					updatedEmployees.add(employeeDTO);
				}
			}

			// Add the unchanged employees to the updated list using a for loop
			for (EmployeeForProject existingEmp : existingProject.getProjManager()) {
				boolean isUpdated = false;
				for (EmployeeForProject updatedEmp : updatedEmployees) {
					if (updatedEmp.getEmpId().equals(existingEmp.getEmpId())) {
						isUpdated = true;
						break;
					}
				}
				if (!isUpdated) {
					updatedEmployees.add(existingEmp);
				}
			}

			projectDTO.setProjManager(updatedEmployees);
		}

		// Collect new employees to be added to the projManager list
		List<EmployeeForProject> newEmployees = new ArrayList<>();
		for (EmployeeForProject emp : projectDTO.getProjManager()) {
			EmployeeForProject newEmployee = consumesDataFromEmployee.getProjectConsumesEmployeeById(emp.getEmpId());
			if (newEmployee != null) {
				newEmployee.setProjId(id); // Set the project ID for the employee
				consumesDataFromEmployee.updateEmployee(newEmployee.getEmpId(), newEmployee); // Update the employee

				// Check for duplicates before adding
				boolean exists = false;
				for (EmployeeForProject manager : projectDTO.getProjManager()) {
					if (manager.getEmpId().equals(newEmployee.getEmpId())) {
						exists = true;
						break;
					}
				}
				if (!exists) {
					newEmployees.add(newEmployee);
				}
			}
		}

		// Add new employees to the projManager list
		projectDTO.getProjManager().addAll(newEmployees);

		if (projectDTO.getProjStatus() == null) {
			projectDTO.setProjStatus(existingProject.getProjStatus());
		}

		ProjectDTO updatedProjectDTO = projectService.updateProject(id, projectDTO);
		return new ResponseEntity<>(updatedProjectDTO, HttpStatus.OK);
	}

}
