package com.training.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.dto.ProjectDTO;
import com.training.entity.Project;
import com.training.exception.BugTracking;
import com.training.repository.ProjectRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	private ProjectRepository projectRepository;

	@Override
	public ProjectDTO addProject(ProjectDTO projectDTO) throws BugTracking {
		// TODO Auto-generated method stub

		Project project = new Project();
		project.setProjName(projectDTO.getProjName());
		project.setProjManager(projectDTO.getProjManager());
		project.setProjStatus(projectDTO.getProjStatus());

		Project savedProject = projectRepository.save(project);

		ProjectDTO savedProjectDTO = new ProjectDTO();
		savedProjectDTO.setProjId(savedProject.getProjId());
		savedProjectDTO.setProjName(savedProject.getProjName());
		savedProjectDTO.setProjManager(savedProject.getProjManager());
		savedProjectDTO.setProjStatus(savedProject.getProjStatus());

		return savedProjectDTO;
	}

	@Override
	public ProjectDTO deleteProject(Long id) throws BugTracking {
		// TODO Auto-generated method stub
		Optional<Project> optionalProject = projectRepository.findById(id);
		projectRepository.delete(optionalProject.orElseThrow(() -> new BugTracking("Service.PROJECT_NOT_FOUND")));
		ProjectDTO projectDTO = new ProjectDTO();
		Project project = optionalProject.get();
		projectDTO.setProjId(project.getProjId());
		projectDTO.setProjName(project.getProjName());
		projectDTO.setProjManager(project.getProjManager());
		projectDTO.setProjStatus(project.getProjStatus());
		return projectDTO;
	}

	@Override
	public ProjectDTO getProject(Long id) throws BugTracking {
		// TODO Auto-generated method stub
		Optional<Project> optionalProject = projectRepository.findById(id);
		Project project = optionalProject.orElseThrow(() -> new BugTracking("Service.PROJECT_NOT_FOUND"));
		ProjectDTO projectDTO = new ProjectDTO();
		projectDTO.setProjId(project.getProjId());
		projectDTO.setProjName(project.getProjName());
		projectDTO.setProjManager(project.getProjManager());
		projectDTO.setProjStatus(project.getProjStatus());
		return projectDTO;
	}

	@Override
	public List<ProjectDTO> getAllProjects() throws BugTracking {
		// TODO Auto-generated method stub
		List<Project> projects = projectRepository.findAll();
		List<ProjectDTO> projectDTOs = new ArrayList<>();
		for (Project project : projects) {
			ProjectDTO projectDTO = new ProjectDTO();
			projectDTO.setProjId(project.getProjId());
			projectDTO.setProjName(project.getProjName());
			projectDTO.setProjManager(project.getProjManager());
			projectDTO.setProjStatus(project.getProjStatus());
			projectDTOs.add(projectDTO);
		}
		if (projectDTOs.isEmpty())
			throw new BugTracking("Service.PROJECTS_NOT_FOUND");
		return projectDTOs;
	}

	@Override
	public ProjectDTO updateProject(Long id, ProjectDTO projectDTO) throws BugTracking {
		// TODO Auto-generated method stub
		Optional<Project> optionalProject = projectRepository.findById(id);
		Project existingProject = optionalProject.orElseThrow(() -> new BugTracking("Service.PROJECT_NOT_FOUND"));
		existingProject.setProjName(projectDTO.getProjName());
		existingProject.setProjManager(projectDTO.getProjManager());
		existingProject.setProjStatus(projectDTO.getProjStatus());

		Project updatedProject = projectRepository.save(existingProject);

		ProjectDTO updatedProjectDTO = new ProjectDTO();
		updatedProjectDTO.setProjId(updatedProject.getProjId());
		updatedProjectDTO.setProjName(updatedProject.getProjName());
		updatedProjectDTO.setProjManager(updatedProject.getProjManager());
		updatedProjectDTO.setProjStatus(updatedProject.getProjStatus());

		return updatedProjectDTO;
	}

}
