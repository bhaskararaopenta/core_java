package com.training.service;

import java.util.List;

import com.training.dto.CustomerDTO;
import com.training.exception.BankException;

public interface CustomerService {
	public Integer addCustomer(CustomerDTO customerDTO) throws BankException;

	public CustomerDTO getCustomer(Integer customerId) throws BankException;

	public void updateCustomer(Integer customerId, CustomerDTO customerDTO) throws BankException;

	public void deleteCustomer(Integer customerId) throws BankException;

	public List<CustomerDTO> getAllCustomers() throws BankException;
}
