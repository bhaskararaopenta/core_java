package com.training.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.dto.EmployeeDTO;
import com.training.entity.Employee;
import com.training.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public EmployeeDTO createEmployee(EmployeeDTO employeeDTO) {
		// Convert DTO to entity
		Employee emp = new Employee();
		emp.setEmpId(employeeDTO.getEmpId());
		emp.setEmpName(employeeDTO.getEmpName());
		emp.setEmail(employeeDTO.getEmail());
		emp.setEmpContact(employeeDTO.getEmpContact());

		Employee savedEmployee = employeeRepository.save(emp);

		// Convert the saved entity back to DTO
		EmployeeDTO savedEmployeeDTO = new EmployeeDTO();
		savedEmployeeDTO.setEmpId(savedEmployee.getEmpId());
		savedEmployeeDTO.setEmpName(savedEmployee.getEmpName());
		savedEmployeeDTO.setEmail(savedEmployee.getEmail());
		savedEmployeeDTO.setEmpContact(savedEmployee.getEmpContact());

		return savedEmployeeDTO;
	}

	@Override
	public EmployeeDTO deleteEmployee(long id) {
		// TODO Auto-generated method stub

		Optional<Employee> employee = employeeRepository.findById(id);

		employeeRepository.delete(employee.get());
		Employee emp = employee.get();
		EmployeeDTO employeeDTO = new EmployeeDTO();
		employeeDTO.setEmpId(emp.getEmpId());
		employeeDTO.setEmpName(emp.getEmpName());
		employeeDTO.setEmail(emp.getEmail());
		employeeDTO.setEmpContact(emp.getEmpContact());

		return employeeDTO;
	}

	@Override
	public EmployeeDTO getEmployee(long id) {
		// TODO Auto-generated method stub

		Optional<Employee> emp = employeeRepository.findById(id);
		Employee exiemp = emp.get();

		EmployeeDTO employeeDTO = new EmployeeDTO();
		employeeDTO.setEmpId(exiemp.getEmpId());
		employeeDTO.setEmpName(exiemp.getEmpName());
		employeeDTO.setEmail(exiemp.getEmail());
		employeeDTO.setEmpContact(exiemp.getEmpContact());
		return employeeDTO;
	}

	@Override
	public List<EmployeeDTO> getAllEmployees() {

		List<EmployeeDTO> employeeDTOs = new ArrayList<>();

		List<Employee> employees = employeeRepository.findAll();

		for (Employee employee : employees) {
			EmployeeDTO dto = new EmployeeDTO();
			dto.setEmpId(employee.getEmpId());
			dto.setEmpName(employee.getEmpName());
			dto.setEmail(employee.getEmail());
			dto.setEmpContact(employee.getEmpContact());

			employeeDTOs.add(dto);
		}

		return employeeDTOs;
	}

	@Override
	public EmployeeDTO updateEmployee(long id, EmployeeDTO employeeDTO) {

		Optional<Employee> optionalEmployee = employeeRepository.findById(id);

		Employee existingEmployee = optionalEmployee.get();

		// Update the employee entity with new values from the DTO
		existingEmployee.setEmpName(employeeDTO.getEmpName());
		existingEmployee.setEmail(employeeDTO.getEmail());
		existingEmployee.setEmpContact(employeeDTO.getEmpContact());

		Employee updatedEmployee = employeeRepository.save(existingEmployee);

		// Convert the updated employee entity to DTO
		EmployeeDTO updatedEmployeeDTO = new EmployeeDTO();
		updatedEmployeeDTO.setEmpId(updatedEmployee.getEmpId());
		updatedEmployeeDTO.setEmpName(updatedEmployee.getEmpName());
		updatedEmployeeDTO.setEmail(updatedEmployee.getEmail());
		updatedEmployeeDTO.setEmpContact(updatedEmployee.getEmpContact());

		return updatedEmployeeDTO;
	}

}
