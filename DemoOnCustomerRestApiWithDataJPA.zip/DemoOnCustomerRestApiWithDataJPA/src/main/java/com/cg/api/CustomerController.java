package com.cg.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Customer;
import com.cg.exception.CgBankException;
import com.cg.service.CustomerService;

@RestController
@RequestMapping("/api") // optional
public class CustomerController {

	@Autowired
	private Environment environment;

	@Autowired
	private CustomerService cService;

	@PostMapping("/customer") // http://localhost:8000/myapp/api/customer --- endpoint url
	public ResponseEntity<String> addCustomer(@RequestBody Customer customer) throws CgBankException {
		int id = cService.addCustomer(customer);
		// String msg = "customer record is inserted" + id;
		String msg = environment.getProperty("API.INSERT_SUCCESS") + "" + id;
		ResponseEntity<String> respEnty = new ResponseEntity<>(msg, HttpStatus.ACCEPTED);
		return respEnty;
	}

	@GetMapping("/customer/{customerId}") // http://localhost:8000/myapp/api/customer/1
	public ResponseEntity<Customer> getCustomerById(@PathVariable("customerId") int id) throws CgBankException {
		Customer c = cService.getCustomerById(id);
		return new ResponseEntity<Customer>(c, HttpStatus.OK);
	}

	@GetMapping("/customers") //// http://localhost:8000/myapp/api/customers
	public ResponseEntity<List<Customer>> getAllCustomer() throws CgBankException {
		List<Customer> c = cService.getAllCustomers();
		return new ResponseEntity<List<Customer>>(c, HttpStatus.OK);
	}

	@DeleteMapping("/customer/{customerId}")
	public ResponseEntity<String> deleteCustomer(@PathVariable("customerId") int id) throws CgBankException {
		String c = cService.deleteCustomerById(id);
		return new ResponseEntity<String>(c, HttpStatus.OK);
	}

	@PutMapping("/customer/{customerId}") //
	public ResponseEntity<String> updateCustomer(@PathVariable("customerId") int id, @RequestBody Customer cust)
			throws CgBankException {
		String c = cService.updateCustomerById(id, cust);
		return new ResponseEntity<String>(c, HttpStatus.OK);
	}

}
