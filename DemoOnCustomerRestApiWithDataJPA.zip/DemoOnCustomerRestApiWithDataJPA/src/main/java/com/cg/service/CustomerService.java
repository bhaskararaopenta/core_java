package com.cg.service;

import java.util.List;

import com.cg.entity.Customer;
import com.cg.exception.CgBankException;

public interface CustomerService {
	public Integer addCustomer(Customer cust) throws CgBankException;

	public Customer getCustomerById(int id) throws CgBankException;

	public List<Customer> getAllCustomers() throws CgBankException;

	public String deleteCustomerById(int id) throws CgBankException;

	public String updateCustomerById(int id, Customer cust) throws CgBankException;
}
