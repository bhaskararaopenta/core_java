package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Customer;
import com.cg.exception.CgBankException;
import com.cg.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository cRepository; // has-a

	@Override
	public Integer addCustomer(Customer cust) throws CgBankException {
		Customer c1 = cRepository.save(cust);
		return c1.getCustomerId();
	}

	@Override
	public Customer getCustomerById(int id) throws CgBankException {
		Optional<Customer> opt = cRepository.findById(id);
		Customer cust = opt.orElseThrow(() -> new CgBankException("record_NOTFOUND"));
		return cust;
	}

	@Override
	public List<Customer> getAllCustomers() throws CgBankException {
		return cRepository.findAll();
	}

	@Override
	public String deleteCustomerById(int id) throws CgBankException {
		Optional<Customer> opt = cRepository.findById(id);
		if (opt.isEmpty()) {
			return "No Recored Exist Based On Id..";
		} else {
			Customer c = opt.get();
			cRepository.delete(c);
			return "Record Deleted Successfully";
		}

	}

	@Override
	public String updateCustomerById(int id, Customer cust) throws CgBankException {
		Optional<Customer> opt = cRepository.findById(id);
		if (opt.isEmpty()) {
			return "No Recored Exist Based On Id..";
		} else {
			Customer c = opt.get();
			c.setName(cust.getName());
			c.setEmail(cust.getEmail());
			c.setDateOfBirth(cust.getDateOfBirth());
			cRepository.save(c);
			return "Record Upated Successfully...!";
		}
	}

}
