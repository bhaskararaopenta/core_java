package com.cg.utility;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cg.exception.CgBankException;

@RestControllerAdvice
public class CustomerRestControllerAdvise {
	
	@Autowired
	private Environment env;

	@ExceptionHandler(CgBankException.class)
	public ResponseEntity<ErrorInfo> exceptionHandler(CgBankException exception) {
		ErrorInfo info = new ErrorInfo();
		info.setErrorMessage(env.getProperty(exception.getMessage()));
		info.setErrorCode(HttpStatus.NOT_FOUND.value());
		info.setTimestamp(LocalDateTime.now());

		return new ResponseEntity<ErrorInfo>(info, HttpStatus.NOT_FOUND); // 404 notfound
	}

}
