package com.cg.exception;

public class CgBankException extends Exception {

	public CgBankException(String msg) {
		super(msg);
	}

}
