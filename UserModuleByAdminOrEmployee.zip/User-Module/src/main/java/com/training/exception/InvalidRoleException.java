package com.training.exception;

public class InvalidRoleException extends Exception{

	public InvalidRoleException(String msg) {
		super(msg);
	}

	
}
