package com.training.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.dto.UserDTO;
import com.training.entity.Admin;
import com.training.entity.Employee;
import com.training.entity.User;
import com.training.exception.InvalidRoleException;
import com.training.repository.AdminRepository;
import com.training.repository.EmployeeRepository;
import com.training.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private AdminRepository adminRepository;

	@Autowired
	private UserRepository userRepository;

	@Override
	public User createUser(UserDTO userDTO) throws InvalidRoleException {

		if ("ADMIN".equalsIgnoreCase(userDTO.getRole())) {

			User user = new User();
			user.setPassword(userDTO.getPassword());
			user.setRole(userDTO.getRole());

			user = userRepository.save(user);

			Admin admin = new Admin();
			admin.setUser(user);
			admin.setAdminName(userDTO.getAdminName());
			admin.setAdminContact(userDTO.getAdminContact());

			adminRepository.save(admin);

			return user;

		} else if ("EMPLOYEE".equalsIgnoreCase(userDTO.getRole())) {

			User user = new User();
			user.setPassword(userDTO.getPassword());
			user.setRole(userDTO.getRole());

			user = userRepository.save(user);

			Employee employee = new Employee();
			employee.setUser(user);
			employee.setEmail(userDTO.getEmail());
			employee.setEmpName(userDTO.getEmpName());
			employee.setEmpContact(userDTO.getEmpContact());

			employeeRepository.save(employee);

			return user;
		} else {
			throw new InvalidRoleException("Role must be either ADMIN or EMPLOYEE");
		}

	}

}
