package com.training.service;

import com.entity.dto.UserDTO;
import com.training.entity.Employee;
import com.training.entity.User;
import com.training.exception.InvalidRoleException;

public interface UserService {

	User createUser(UserDTO userDTO) throws InvalidRoleException;
	
	
}
