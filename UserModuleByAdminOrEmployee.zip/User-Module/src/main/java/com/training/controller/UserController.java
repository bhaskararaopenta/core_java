package com.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.dto.UserDTO;
import com.training.entity.User;
import com.training.exception.InvalidRoleException;
import com.training.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;

	@PostMapping("/create")
	public ResponseEntity<User> createUser(@RequestBody UserDTO userDTO) throws InvalidRoleException {
		User cu = userService.createUser(userDTO);
		return new ResponseEntity<User>(cu, HttpStatus.CREATED);
	}
}
