package com.training.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.training.entity.Admin;
import com.training.entity.User;

public interface AdminRepository extends JpaRepository<Admin, Long> {

	Admin findByUser(User user);
}
