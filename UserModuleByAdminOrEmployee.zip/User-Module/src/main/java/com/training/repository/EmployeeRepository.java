package com.training.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.training.entity.Employee;
import com.training.entity.User;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

	 Employee findByUser(User user);
}
