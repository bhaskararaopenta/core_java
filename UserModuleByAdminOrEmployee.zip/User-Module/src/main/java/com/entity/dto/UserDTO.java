package com.entity.dto;

public class UserDTO {

	private String password;
	private String role;

	private String adminName;
	private String adminContact;

	private String empName;
	private String email;
	private String empContact;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getAdminContact() {
		return adminContact;
	}

	public void setAdminContact(String adminContact) {
		this.adminContact = adminContact;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmpContact() {
		return empContact;
	}

	public void setEmpContact(String empContact) {
		this.empContact = empContact;
	}

	@Override
	public String toString() {
		return "UserDTO [password=" + password + ", role=" + role + ", adminName=" + adminName + ", adminContact="
				+ adminContact + ", empName=" + empName + ", email=" + email + ", empContact=" + empContact + "]";
	}

}
