package com.cg.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Customer;
import com.cg.service.CustomerService;

@RestController
@RequestMapping("/api") //optional
public class CustomerController {
	@Autowired
	private CustomerService cService;

	@PostMapping("/customer") //http://localhost:8000/myapp/api/customer  --- endpoint url
	public String addCustomer(@RequestBody Customer customer) {
		int id=cService.addCustomer(customer);
		return "Customer Record is inserted : "+id;  
	}
	
	@GetMapping("/customer/{customerId}")//http://localhost:8000/myapp/api/customer/1
	public Customer getCustomerById(@PathVariable("customerId") int id) {
		return cService.getCustomerById(id);
	}
	
	@GetMapping("/customers")////http://localhost:8000/myapp/api/customers
	public List<Customer> getAllCustomer(){
		return  cService.getAllCustomers();
		
	}
	
	@DeleteMapping("/customer/{customerId}")
	public String deleteCustomer(@PathVariable("customerId") int id) {
		return cService.deleteCustomerById(id);
	} 

	@PutMapping("/customer/{customerId}")//
	public String updateCustomer(@PathVariable("customerId") int id,@RequestBody Customer cust) {
		return cService.updateCustomerById(id, cust);
	} 


}
