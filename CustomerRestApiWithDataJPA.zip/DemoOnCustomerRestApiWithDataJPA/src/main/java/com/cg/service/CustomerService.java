package com.cg.service;

import java.util.List;

import com.cg.entity.Customer;

public interface CustomerService {
    public Integer addCustomer(Customer cust);
    public Customer getCustomerById(int id);
    public List<Customer>  getAllCustomers();
    public String deleteCustomerById(int id);
    public String updateCustomerById(int id,Customer cust);
}
