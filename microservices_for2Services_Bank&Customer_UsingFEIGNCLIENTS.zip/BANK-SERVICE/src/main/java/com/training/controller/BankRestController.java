package com.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.consumes.BankCustomerRestApiConsumes;
import com.training.dto.CustomerDTO;

@RestController
@RequestMapping("/test")
public class BankRestController {

	@Autowired
	private BankCustomerRestApiConsumes consumes;

	@GetMapping("/allcustomers")
	public ResponseEntity<List<CustomerDTO>> getBankAllCustomers() {

		List<CustomerDTO> ls = consumes.getAllCustomers(); // calling from interface

		return new ResponseEntity<>(ls, HttpStatus.OK);
	}

	@GetMapping("/bankcustomer/{id}")
	public CustomerDTO getBankCustomerById(@PathVariable Integer id) {

		return consumes.getBankConusmesCustomerById(id);

	}

	@PostMapping("/add")
	public String addCustomerThroughBank(@RequestBody CustomerDTO custdto) {
		return consumes.fromBankAddCustomer(custdto);
	}

	@DeleteMapping("/delete/{id}")
	public String deletBankCustomerById(@PathVariable Integer id) {

		return consumes.deletBankConusmesCustomerById(id);

	}

	@PutMapping("/update/{id}")
	public String updateCustomerById(@PathVariable Integer id, @RequestBody CustomerDTO customer) {
		return consumes.updateCustomerById(id, customer);
	}

}
